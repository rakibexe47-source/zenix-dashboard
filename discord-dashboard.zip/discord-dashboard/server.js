const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

// ---- Mock/live data endpoint -------------------------------------------
// Replace the values below with real numbers from your bot process
// (e.g. via a shared database, Redis, or your discord.js client object).
const startedAt = Date.now();

app.get('/api/stats', (req, res) => {
  const uptimeMs = Date.now() - startedAt;
  const days = Math.floor(uptimeMs / 86400000);
  const hours = Math.floor((uptimeMs % 86400000) / 3600000);
  const minutes = Math.floor((uptimeMs % 3600000) / 60000);

  res.json({
    botName: process.env.BOT_NAME || 'MYBOT',
    status: 'online',
    servers: 12,
    serversDelta: 2,
    members: 8432,
    membersDelta: 154,
    uptime: `${days}d ${hours}h ${minutes}m`,
    system: { cpu: 12, memory: 46, disk: 28, network: 5 },
    guilds: [
      { name: 'Galaxy Hub', members: 2341, status: 'online' },
      { name: 'Shadow Empire', members: 1203, status: 'online' },
      { name: 'Zenith Community', members: 842, status: 'online' },
      { name: 'Anime World', members: 674, status: 'online' },
      { name: 'Tech Zone', members: 521, status: 'online' }
    ],
    logs: [
      { time: '01:42:12', level: 'INFO', msg: 'Bot is ready! Serving 12 guilds and 8432 members.' },
      { time: '01:41:55', level: 'INFO', msg: 'Lavalink connected successfully.' },
      { time: '01:41:20', level: 'INFO', msg: 'Loaded 152 emojis.' },
      { time: '01:41:18', level: 'INFO', msg: 'Commands registered: 36 (no duplicates).' },
      { time: '01:41:15', level: 'INFO', msg: 'Database connected.' },
      { time: '01:41:02', level: 'INFO', msg: 'Bot started successfully.' }
    ]
  });
});

app.listen(PORT, () => {
  console.log(`Dashboard running on port ${PORT}`);
});
