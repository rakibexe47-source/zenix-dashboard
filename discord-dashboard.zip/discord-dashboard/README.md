# Discord Bot Dashboard

তোমার Discord bot-এর জন্য রেডি-মেড dashboard — ছবিতে দেখানো UI/UX-এর মতোই ডিজাইন করা।
Node.js + Express দিয়ে বানানো, তাই Render-এ সরাসরি deploy করা যাবে।

## গঠন (structure)
```
discord-dashboard/
├── server.js          # Express server + /api/stats endpoint
├── package.json
└── public/
    ├── index.html     # ড্যাশবোর্ডের HTML
    ├── style.css      # ডার্ক থিম, ছবির মতো লেআউট
    └── script.js      # /api/stats থেকে ডেটা এনে UI আপডেট করে
```

## নিজের মতো customize করবে যেভাবে

1. **বটের নাম, owner, node, port** — `server.js`-এর `/api/stats` route-এ যে object আছে,
   ওখানে বসাও (অথবা `.env`-এ `BOT_NAME` সেট করে দাও)।
2. **আসল লাইভ ডেটা দেখাতে চাইলে** — তোমার discord.js bot process থেকে
   `client.guilds.cache.size`, `client.users.cache.size` ইত্যাদি একটা shared
   database/Redis/JSON ফাইলে লিখে রাখো, আর `server.js`-এর `/api/stats`
   route থেকে সেটা read করে পাঠাও।
3. **রং/লোগো বদলাতে** — `style.css`-এর উপরে `:root { --blue: ... }` ভেরিয়েবলগুলো,
   আর `index.html`-এ `Z` লোগো-অক্ষরটা বদলে দাও।
4. **Sidebar-এর মেনু আইটেম** (Servers, Commands, Features...) `index.html`-এর
   `.nav` অংশে আছে — নতুন পেজ বানালে সেখানে লিংক যোগ করবে।

## লোকাল টেস্ট
```bash
npm install
npm start
# http://localhost:3000 -এ খুলবে
```

## Render-এ Deploy করার ধাপ

1. এই ফোল্ডারটা একটা GitHub রিপোতে push করো।
2. [render.com](https://render.com) → **New +** → **Web Service**।
3. তোমার GitHub রিপো select করো।
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Environment:** Node
5. (ঐচ্ছিক) **Environment Variables**-এ `BOT_NAME=তোমার বটের নাম` যোগ করো।
6. **Create Web Service** চাপো — কয়েক মিনিটে একটা লাইভ URL পেয়ে যাবে
   (যেমন `https://your-bot-dashboard.onrender.com`)।

> Free tier-এ Render কিছুক্ষণ inactive থাকলে service ঘুমিয়ে যায় — প্রথম
> রিকোয়েস্টে লোড হতে কয়েক সেকেন্ড লাগতে পারে, এটা স্বাভাবিক।

## পরের ধাপ (ঐচ্ছিক)
- Discord OAuth2 login যোগ করে সত্যিকারের owner-only dashboard বানানো যায়
  (`passport-discord` প্যাকেজ দিয়ে)।
- `/api/stats`-কে discord.js bot-এর সাথে সরাসরি যুক্ত করলে সংখ্যাগুলো
  রিয়েল-টাইম হয়ে যাবে।
