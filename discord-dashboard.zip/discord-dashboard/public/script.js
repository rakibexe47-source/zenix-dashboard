const guildColors = ['#ef4444', '#3b82f6', '#a855f7', '#ec4899', '#f59e0b', '#10b981'];

function fmt(n){ return n.toLocaleString('en-US'); }

async function loadStats(){
  try{
    const res = await fetch('/api/stats');
    const data = await res.json();
    render(data);
  }catch(err){
    console.error('Could not load stats', err);
  }
}

function render(data){
  document.getElementById('year').textContent = new Date().getFullYear();

  ['brandName','promoTitle','brandFooter','heroName','overviewName','quoteBrand']
    .forEach(id => { const el = document.getElementById(id); if(el) el.textContent = data.botName; });

  document.getElementById('statServers').textContent = fmt(data.servers);
  document.getElementById('statServersDelta').textContent = `↑ +${data.serversDelta}`;
  document.getElementById('statMembers').textContent = fmt(data.members);
  document.getElementById('statMembersDelta').textContent = `↑ +${data.membersDelta}`;
  document.getElementById('statUptime').textContent = data.uptime;

  // Guild list
  const list = document.getElementById('guildList');
  list.innerHTML = '';
  data.guilds.forEach((g, i) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <div class="guild-icon" style="background:${guildColors[i % guildColors.length]}">${g.name.charAt(0)}</div>
      <span class="guild-name">${g.name}</span>
      <span class="guild-members">${fmt(g.members)} members</span>
      <span class="guild-status"><span class="dot online"></span> ${g.status}</span>
      <span class="guild-arrow">›</span>
    `;
    list.appendChild(li);
  });

  // System bars
  const bars = document.getElementById('systemBars');
  bars.innerHTML = '';
  const rows = [
    ['CPU Usage', data.system.cpu],
    ['Memory Usage', data.system.memory],
    ['Disk Usage', data.system.disk],
    ['Network Usage', data.system.network]
  ];
  rows.forEach(([label, val]) => {
    const row = document.createElement('div');
    row.className = 'bar-row';
    row.innerHTML = `
      <div class="bar-top"><span>${label}</span><span>${val}%</span></div>
      <div class="bar-track"><div class="bar-fill" style="width:${val}%"></div></div>
    `;
    bars.appendChild(row);
  });

  // Logs
  const logs = document.getElementById('logList');
  logs.innerHTML = '';
  data.logs.forEach(l => {
    const row = document.createElement('div');
    row.className = 'log-row';
    row.innerHTML = `<span class="log-time">${l.time}</span><span class="log-level">[${l.level}]</span><span class="log-msg">${l.msg}</span>`;
    logs.appendChild(row);
  });
}

loadStats();
setInterval(loadStats, 15000);
